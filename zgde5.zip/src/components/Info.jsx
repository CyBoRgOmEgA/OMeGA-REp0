import React from "react";


function Info(){
  return(
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>a basic web development React.js bootcamp</p>
    </div>
  );
}

export default Info;